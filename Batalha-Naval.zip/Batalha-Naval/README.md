
Este site é um teste do jogo batalha naval para o curso de Front End do Senai

Como Jogar?
    1 - Clique no Modo. 
      - Facil(15 tiros)
      - Dificil (10 tiros)
    2 - Clique em Posicionar.  
    3 - Clique na tabela com  o mouse para posicionar os disparos.
    4 - Pontuação:
      - A cada disparo no barco soma-se 10 pontos.
